<?php


class fidel
{
    private $FID;
    private $score;
    private $mail;
    private $promotion;


    function __construct($FID,$score,$mail,$promotion)
    {
        $this->FID=$FID;
        $this->score=$score;
        $this->mail=$mail;
        $this->promotion=$promotion;
    }

/*GET*/

    public function getFID()
    {
        return $this->FID;
    }


    public function getscore()
    {
        return $this->score;
    }



    public function getmail()
    {
        return $this->mail;
    }

     public function getpromotion()
    {
        return $this->promotion;
    }


/*SET*/

    public function setFID($FID)
    {
        $this->FID = $FID;
    }


    public function setscore($score)
    {
        $this->score = $score;
    }


    public function setmail($mail)
    {
        $this->mail = $mail;
    }

     public function setpromotion($mail)
    {
        $this->promotion = $promotion;
    }
}
