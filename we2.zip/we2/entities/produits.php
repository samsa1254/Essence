<?php


class produits
{
    private $idpp;
    private $nomprodprod;
    private $description;
    private $categorie;
    private $prix;
    private $quantite;
    private $image;

     function __construct($idp,$nomprod,$description,$categorie,$prix,$quantite,$image)
     {
        $this->idp=$idp;
        $this->nomprod=$nomprod;
        $this->description=$description;
        $this->categorie=$categorie;
        $this->prix=$prix;
        $this->quantite=$quantite;
        $this->image=$image;
     }


     public function getidp()
     {
        return $this->idp;
     }


     public function getnomprod()
     {
        return $this->nomprod;
     }


     public function getdescription()
     {
        return $this->description;
     }


     public function getcategorie()
     {
        return $this->categorie;
     }


     public function getprix()
     {
        return $this->prix;
     }

     public function getquantite()
     {
        return $this->quantite ;
     }


     public function getimage()
     {
        return $this->image;
     }


     public function setidp($idp)
     {
         $this->idp = $idp;
     }


     public function setnomprod($nomprod)
     {
        $this->nomprod = $nomprod;
     }


     public function setdescription($description)
     {
        $this->description = $description;
     }


     public function setcategorie($categorie)
     {
        $this->categorie = $categorie;
     }

     public function setprix($prix)
      {
        $this->prix = $prix;
      }
     public function setquantite($quantite)
      {
        $this->quantite = $quantite;
      }


      public function setimage($image)
      {
        $this->image = $image;
       }

}

?>
