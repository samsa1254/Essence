<?php


class categorie
{
    private $id;
    private $nom;
    private $description;
   

     function __construct($id,$nom,$description)
     {
        $this->id=$id;
        $this->nom=$nom;
        $this->description=$description;
     }

     public function getid()
     {
        return $this->id;
     }

    
     public function getnom()
     {
        return $this->nom;
     }

    
     public function getdescription()
     {
        return $this->description;
     }





     public function setid($id)
     {
         $this->id = $id;
     }

  
     public function setnom($nom)
     {
        $this->nom = $nom;
     }

   
     public function setdescription($description)
     {
        $this->description = $description;
     }

   
   

}

?>