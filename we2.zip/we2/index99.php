<?php include"header3.php" ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Soujoud- verification </title>

   <!-- Favicon
   <link rel="icon" href="img/core-img/favicon.ico">
-->
    <!-- Core Style CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">
    <!--<link rel="stylesheet" href="style.css"> -->
    <script type="text/javascript" src="verifier.js">

    </script>
</head>

<body>

    <!-- ##### Checkout Area Start ##### -->
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 form-div">

<div class="alert alert-succes">
vous etes maintenant un nouveau membre!
</div>
<div class="alert alert-succes">
Bienvenu!
</div>
<div class="aler aler-warning">
Un lien de verification a ete envoyé a votre email,veuillez le verifier pour se connecter!
</div>
<input type="submit" name="verif" value=" j'ai verifier mon compte! " class="btn btn-block btn-lg btn-primary">
<a href="logout.php">Deconnexion</a>

</body>

</html>
