<?php
include "core/userC.php";
include "entities/user.php";
session_start();
/*if(isset($_POST['adresse1']))
{
  $client=new utilisateur("","",$_SESSION['l'],"","",$_POST['adresse1'],"","","","","");
  $useC=new utilisateurCore();
  $useC->modifierUser($client,$_SESSION['l']);
  header("location:account.php");
}*/

if (isset($_POST['uname'])&&isset($_POST['unam'])&&isset($_POST['unpre'])&&isset($_POST['ville'])&&isset($_POST['zipzip'])&&isset($_POST['addrisa'])&&isset($_POST['tal'])&&isset($_POST['pass']) )
    {
        $u= new utilisateurCore();

            $u->editUser($_POST['unam'],$_POST['unpre'],$_POST['uname'],$_POST['pass'],$_POST['addrisa'],$_POST['ville'],$_POST['zipzip'],$_POST['tal'],$_SESSION['l']);
            header("location:afficherdata.php");

    }
    else
    {
        echo "salem thabet rou7ek";
    }

?>
