
<?php
   include 'core/commentaireC.php';
include 'header1.php';

   $prd=1;
   $e=new EmployeC();
   $liste=$e->afficherEmployes($prd);


?>

<?php
   include 'core/produitsC.php';
include 'header1.php';

   
   $produit=new produitsC();
   $listep=$produit->afficherproduits();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Soujoud - Fashion Ecommerce Template</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

</head>

<body>

    <!-- ##### Header Area End ##### -->




      <section class="banner-bottom py-lg-5 py-3">
         <div class="container">
            <div class="inner-sec-shop pt-lg-4 pt-3">
               <div class="row">
                <?php
                foreach ($listep as $row)
                  ?>
                  <div class="col-lg-4 single-right-left ">
                     <div class="grid images_3_of_2">
                        <div class="flexslider1">
                           <ul class="slides">

                              <li data-thumb="images/.jpg">
                                 <div class="thumb-image"> <img src="<?php echo $row['image']; ?> data-imagezoom="true" class="img-fluid" alt=" "> </div>
                              </li>
                              
                           </ul>
                           <div class="clearfix"></div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-8 single-right-left simpleCart_shelfItem">
                     <h3><?php echo $row['nomprod']; ?></h3>
                     <p><span class="item_price"><?php echo $row['prix']; ?></span>
                        <del>$1,199</del><?php ?>
                     </p>


                     <table>
                     <tr>
                   <form method="POST" action="traitement2.php">


                        <td><button class="btn"><i class="fa fa-thumbs-up"></i></button></td>

                        <input type="hidden" value= "1" name="react" id="react" >
                        <input type="hidden" value="<?php echo $_SESSION["l"]; ?>" name="user" id="user">
                        <input type="hidden" value= "<?php echo $prd; ?>" name="id_produit" id="id_produit" >
                    <td>
                     <?php
$db=config::getconnexion();
$req="SELECT  SUM(react)  FROM reaction WHERE react=1 and id_produit= $prd";
$list=$db->query($req);
foreach ($list as $row)
echo '('.$row[0].')';
?>
</td>
 </form>


<form method="POST" action="traitement2.php">
                       <td> <button class="btn"><i class="fa fa-thumbs-down"></i></button></td>

                        <input type="hidden" value= "-1" name="react" id="react" >
                        <input type="hidden" value="<?php echo $_SESSION["l"]; ?>" name="user" id="user">
                         <input type="hidden" value= "<?php echo $prd; ?>" name="id_produit" id="id_produit" >


                     <td>
                      <?php
$db=config::getconnexion();
$req="SELECT  SUM(react)  FROM reaction WHERE react=-1 and id_produit= $prd";
$list=$db->query($req);
foreach ($list as $row)
 $s=($row[0])*(-1);
echo '('.$s.')';
?>

   <button type="button" data-toggle="modal" data-target="#exampleModa2"> <span class="fas fa-users"></span> Likes / Dislikes </button>


</td>
</form>
</tr>



<div class="tab-cnt">

   <div class="tab-tr" id="t1">


        <div class="stat-cnt">
         <div class="rate-count"></div>
             <div class="stat-bar">
               <div class="bg-green" style="width:"></div>
                <div class="bg-red" style="width:"></div>
              </div>




</table>




                           <!--//tab_one-->
                           <center>
                           <div class="tab2">
                              <div class="single_page">
                                 <div class="bootstrap-tab-text-grids">
                                    <div class="bootstrap-tab-text-grid">
                                       <div class="bootstrap-tab-text-grid-left">

                                       </div>
                                       <div class="bootstrap-tab-text-grid-right">
                                          <ul>

                                          </ul>

                                       </div>
                                       <div class="clearfix"> </div>
                                    </div>
                                    <div>




                                       <h6>Commentaire</h6>
      <br>
      <table class="table table-sm">
         <tr>

            <th><h4>nom</h4></th>

            <th><h4>msg</h4></th>

         </tr>
         <?php
            foreach ($liste as $row)
               {
                  echo '<tr>';

                     echo '<td>'.$row['nom'].'</td>';

                     echo '<td>'.$row['msg'].'</td>';

                      echo '<td></td>';


                       if(isset($_SESSION["l"]))
 {
?>


                       <form method="POST" action="traitement3.php">
                        <td><button class="btn"><i class="fa fa-heart" name="like" value="LIKE"></i></button></td>

                     <input type="hidden" value="<?php echo $row['num']; ?>" name="numcom">
                     <input type="hidden" value="<?php echo $_SESSION["l"]; ?>" name="userr">

                     </form>
                      <?php
                      $a=$row['num'];
                      $result = $db->query("SELECT idl FROM comlike WHERE numcom = $a");
                        $count=$result->rowCount();

                       echo '<td>('.$count.')</td>';



                  if($_SESSION["l"]==$row['nom'])
                      {
                      ?>

<td><a class="btn btn-primary btn-sm" href="m.php?num='<?php echo $row['num']?>'" >Modifier</a></td>

                      <form method="POST" action="supprimerCommentaire.php">
                             <td> <input type="submit" class="btn btn-danger btn-sm"name="supprimer" value="supprimer"></td>

                              <input type="hidden" value="<?php echo $row['num']; ?>" name="num">
                     </form>


<?php
}
echo'<tr>';
}
               }
         ?>
      </table>
      <br>

   </div>
                                    <?php
                                             if(isset($_SESSION["l"]))
 {
   ?>
    <div class="add-review">
                                       <h4>add a review</h4>
                                       <form method="POST" action="traitement.php">
                                          <div class="row">

                                             <input type="hidden" value="<?php echo $_SESSION["l"]; ?>" name="nom" id="nom">




                                 <input type="hidden" value= "<?php echo $_SESSION["a"]; ?>" name="address" id="address" >

                                          </div>
                                          <textarea name="msg" id="msg" ></textarea>
                                          <td><span id="missmsg"></span></td>
                                           <input type="hidden" value= "<?php echo $prd; ?>" name="id_produit" id="id_produit" >

                                          <input type="submit" name="Ajouter" value="SEND" id="bouton" onclick="validation()">
</form>
                                           <?php
 }
   ?>


                                    </div>
                                 </div>
                              </div>

                           </div>
                        </center>


                     </div>
                  </div>
                  <!--//tabs-->
               </div>
            </div>
         </div>
      </section>





    <!-- ##### Right Side Cart Area ##### -->
    <div class="cart-bg-overlay"></div>

    <div class="right-side-cart-area">

        <!-- Cart Button -->
        <div class="cart-button">
            <a href="#" id="rightSideCart"><img src="img/core-img/bag.svg" alt=""> <span>3</span></a>
        </div>

        <div class="cart-content d-flex">

            <!-- Cart List Area -->
            <div class="cart-list">
                <!-- Single Cart Item -->
                <div class="single-cart-item">
                    <a href="#" class="product-image">
                        <img src="img/product-img/product-1.jpg" class="cart-thumb" alt="">
                        <!-- Cart Item Desc -->
                        <div class="cart-item-desc">
                          <span class="product-remove"><i class="fa fa-close" aria-hidden="true"></i></span>
                            <span class="badge">Mango</span>
                            <h6>Button Through Strap Mini Dress</h6>
                            <p class="size">Size: S</p>
                            <p class="color">Color: Red</p>
                            <p class="price">$45.00</p>
                        </div>
                    </a>
                </div>

                <!-- Single Cart Item -->
                <div class="single-cart-item">
                    <a href="#" class="product-image">
                        <img src="img/product-img/product-2.jpg" class="cart-thumb" alt="">
                        <!-- Cart Item Desc -->
                        <div class="cart-item-desc">
                          <span class="product-remove"><i class="fa fa-close" aria-hidden="true"></i></span>
                            <span class="badge">Mango</span>
                            <h6>Button Through Strap Mini Dress</h6>
                            <p class="size">Size: S</p>
                            <p class="color">Color: Red</p>
                            <p class="price">$45.00</p>
                        </div>
                    </a>
                </div>

                <!-- Single Cart Item -->
                <div class="single-cart-item">
                    <a href="#" class="product-image">
                        <img src="img/product-img/product-3.jpg" class="cart-thumb" alt="">
                        <!-- Cart Item Desc -->
                        <div class="cart-item-desc">
                          <span class="product-remove"><i class="fa fa-close" aria-hidden="true"></i></span>
                            <span class="badge">Mango</span>
                            <h6>Button Through Strap Mini Dress</h6>
                            <p class="size">Size: S</p>
                            <p class="color">Color: Red</p>
                            <p class="price">$45.00</p>
                        </div>
                    </a>
                </div>
            </div>

            <div class="modal fade" id="exampleModa2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                                    <h5 class="modal-title" id="exampleModalLabel">Likes</h5>

                  <div class="register-form">
<?PHP

$sql="SELECT * FROM reaction where react=1";
         $db=config::getConnexion();
         $list=$db->query($sql);

         foreach ($list as $row)
               {
                  echo '<tr>';
                     echo '<td>'.$row['user'].'               </td>';


                  echo'<tr>';
               }
?>
                    <h5 class="modal-title" id="exampleModalLabel">DisLikes</h5>
<?PHP

$sql="SELECT * FROM reaction where react=-1";
         $db=config::getConnexion();
         $list=$db->query($sql);

         foreach ($list as $row)
               {
                  echo '<tr>';
                     echo '<td>'.$row['user'].'               </td>';


                  echo'<tr>';
               }
?>
 </div>

               </div>
               <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

               </div>
            </div>
         </div>
      </div>

            <!-- Cart Summary -->





    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Classy Nav js -->
    <script src="js/classy-nav.min.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>
