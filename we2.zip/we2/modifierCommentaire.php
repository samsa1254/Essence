<?php 

include "../../entities/commentaire.php";
include "../../core/commentaireC.php";
if (isset($_POST['modifier'])){

	$eventCore = new employeC();
	$eventCore->modifierEmploye($_POST,$_POST['numn']);
	//echo $_POST['Nom_ini'];
	header('Location:single.php');
	
}
?>

<!DOCTYPE HTML>
<html>

<body>	

<div class="inner-block">
<?php
if (isset($_GET['num'])){
	$Event=new employeC();
    $result=$Event->recupererEmploye($_GET['num']);
	foreach($result as $row){
		$num=$row['num'];
		$nom=$row['nom'];
		$address=$row['address'];
		$msg=$row['msg'];
	}
?>
<form method="POST">
<table>
<caption>Modifier commentaire</caption>
<tr>
<td>num</td>
<td><input type="hidden" name="num" value="<?PHP echo $num ?>"></td>
</tr>
<tr>
<td>Nom</td>
<td><input type="hidden" name="nom" value="<?PHP echo $nom ?>"></td>
</tr>
<tr>
<td>Address</td>
<td><input type="hidden" name="address" value="<?PHP echo $address ?>"></td>
</tr>
<tr>
<td>msg</td>
<td><input type="text" name="msg" value="<?PHP echo $msg ?>"></td>
</tr>

<tr>
<td></td>
<td><input type="submit" name="modifier" value="modifier"></td>
</tr>
<tr>
<td></td>
<td><input type="hidden" name="numn" value="<?PHP echo str_replace('\'', '', $_GET['num']);?>"></td>
</tr>

</table>
</form>
<?PHP
}

?>
</div>

</html>