<?php
include"header3.php";
;?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>verification</title>
  </head>
  <body>
    <h4>"votre compte a ete cree, veuillez verifier votre email!"</h4>
    <form action="verification2.php" method="post">
                                    <div class="form-group">
                                        <label>Email Address</label>
                                        <input class="au-input au-input--full" type="email" name="mailconnect" placeholder="Email">
                                    </div>
                                    <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">sign in</button>
                                    <div class="social-login-content">

  </body>
</html>
