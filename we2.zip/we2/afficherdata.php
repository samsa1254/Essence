<?php
include 'core/userC.php';
include'header3.php';
session_start();
$use = new utilisateurCore();
$listuser =$use->afficherUsers($_SESSION['l']);
foreach ($listuser as $t)
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/style.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!--Include the above in your HEAD tag ---------->

<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
<div class="checkout_area section-padding-40">
    <div class="container">
        <div class="row">
         <div class="col-md-7 offset-md-3 form-div" style="top:100px">
           <form class="" action="modifieruser.php" method="post">
                     <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="pseudo">pseudo<span>*</span></label>
                                <input type="text" name="uname" value="<?php echo $t['pseudo']; ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="first_name">Nom<span>*</span></label>
                                <input type="text" name="unam" value="<?php echo $t['nom']; ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="last_name">Prenom<span>*</span></label>
                                <input type="text" name="unpre" value="<?php echo $t['prenom']; ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="mot-depasse">mot de passe<span>*</span></label>
                                <input type="password" name="pass" value="<?php echo $t['mdp']; ?>">
                            </div>
                                  <div class="col-12 mb-3">
                                <label for="ville">Ville <span>*</span></label>
                                <select class="w-100" name="ville" id="ville" required class="form-control form-control-lg">
                                    <option value="usa">Bizerte</option>
                                    <option value="uk">Grand Tunis</option>
                                    <option value="ger">Beja</option>
                                    <option value="fra">Jendouba</option>
                                    <option value="ind">Nabeul</option>
                                    <option value="aus">Zaghouan</option>
                                    <option value="bra">Siliana</option>
                                    <option value="cana">le Kef</option>
                                    <option value="usa">Kairouan</option>
                                    <option value="uk">Mahdia</option>
                                    <option value="ger">Gabes</option>
                                    <option value="fra">Tozeur</option>
                                    <option value="ind">Medenine</option>
                                    <option value="aus">Jerba</option>
                                    <option value="bra">Tataouine</option>
                                </select>
                            </div>
                            <div class="col-12 mb-3">
                                <label for="postcode">Code postal <span>*</span></label>
                                <input type="text" name="zipzip" value="<?php echo $t['zip']; ?>">
                           </div>
                           <div class="col-md-6 mb-3">
                               <label for="adresse">adresse<span>*</span></label>
                               <input type="text" name="addrisa" value="<?php echo $t['adresse']; ?>">
                           </div>
                            <div class="col-12 mb-3">
                                <label for="phone_number">telephone <span>*</span></label>
                                <input type="number" name="tal" value="<?php echo $t['tel']; ?>">
                            </div>
                                <div class="form-group">
                                  <input type="submit" name="signup-bt" value="modifier" class="btn btn-primary btn-block btn-lg" >
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            </div>
        </div>
    </div>
</div>
<!-- ##### Checkout Area End ##### -->

</table>
  <a href="supp.php" >supprimer votre compte</a>
