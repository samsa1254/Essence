<?php

include "config.php";

class fidelC
{
    function ajouterfidel($fidel)
    {
        $sql= "INSERT into soujoud.fidel (FID, score, mail, promotion) values (:FID,:score,:mail,:promotion)";
        $db = config::getConnexion();
        try
        {
            $req=$db->prepare($sql);
            $FID=$fidel->getFID();
            $score=$fidel->getscore();
            $mail=$fidel->getmail();
            $promotion=$fidel->getpromotion();

            $req->bindValue(':FID',$FID);
            $req->bindValue(':score',$score);
            $req->bindValue(':mail',$mail);
            $req->bindValue(':promotion',$promotion);
            $req->execute();
            echo '<script type="text/JavaScript">  alert("Ajout termineè"); </script>' ;
            header("location : form.php");
        }

        catch (Exception $e)
        {
            echo '<script type="text/JavaScript">alert("ID non existant ! Verifier vos parametres !"); </script>' ;
            die("ID non existant ! Verifier vos parametres !");
            header("location : index2.php");

        }

    }
    function afficherfidel()
    {

        $sql="SELECT * from soujoud.fidel order by score asc";
        $db = config::getConnexion();
        try
        {
            $list=$db->query($sql);
            return $list;
        }
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
    }

   function supprimerfidel($FID){
        $sql="DELETE FROM fidel where FID= :FID";
        $db = config::getConnexion();
        $req=$db->prepare($sql);
        $req->bindValue(':FID',$FID);
        try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
}

    function modifierfidel($FID,$score,$mail,$fidel)
    {
        $sql="UPDATE soujoud.fidel set score= '$score', FID='$FID' where  mail='$mail'";
        $db = config::getConnexion();
        try
        {
            $db->query($sql);
        }
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
    }

}
