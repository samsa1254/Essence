<?php

include "config.php";
class categorieC
{
    function ajoutercategorie($categorie)


    {
        $sql = "insert into categories(id,nom,description) values (:id,:nom,:description)";
        $db = config::getConnexion();
        try {
            $req = $db->prepare($sql);
            $id = $categorie->getid();
            $nom = $categorie->getnom();
            $description = $categorie->getdescription();
           

            $req->bindValue(':id', $id);
            $req->bindValue(':nom', $nom);
            $req->bindValue(':description', $description);
        

            $req->execute();

        } catch (Exception $e) {
            die('Erreur: Un categorie avec ce id existe deja');

        }
    }

    function affichercategorie()
    {
        $sql="select * from soujoud.categories";

        $db = config::getConnexion();
        try
        {
            $list=$db->query($sql);
            return $list;
        }
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
    }

    function modifiercat($id,$nom,$description)
    {
        $sql="update categories set nom= '$nom', description='$description' where id='$id'";
        $db = config::getConnexion();
        try
        {
            $db->query($sql);
        }
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
    }

    function suppcategorie($id)
    {
        $sql="DELETE FROM soujoud.categories WHERE id LIKE '$id' ESCAPE '#'";
        $db = config::getConnexion();
        try
        {
            $db->query($sql);
        }
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
    }

}

?>