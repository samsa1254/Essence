<?php
include "config1.php";

class produitsC
{
    function ajouterproduits($produits)


    {
        $sql = "insert into soujoud.produits(idp,nomprod,description,categorie,prix,quantite,image) values (:idp,:nomprod,:description,:categorie,:prix,:quantite,:image)";
        $db = config11::getConnexion();
        try {
            $req = $db->prepare($sql);
            $idp = $produits->getidp();
            $nomprod = $produits->getnomprod();
            $description = $produits->getdescription();
            $categorie = $produits->getcategorie();
            $prix = $produits->getprix();
            $quantite = $produits->getquantite();
            $image = $produits->getimage();
            $req->bindValue(':idp', $idp);
            $req->bindValue(':nomprod', $nomprod);
            $req->bindValue(':description', $description);
            $req->bindValue(':categorie', $categorie);
            $req->bindValue(':prix', $prix);
            $req->bindValue(':quantite', $quantite);
            $req->bindValue(':image', $image);

            $req->execute();

        } catch (Exception $e) {
            die('Erreur: Un produits avec ce idp existe deja');

        }
    }
    function graphe()

    {
        $sql = "SELECT nomprod,prix FROM produits ";
        $db = config11::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    function afficherproduits()
    {
        $sql="select * from soujoud.produits";

        $db = config11::getConnexion();
        try
        {
            $list=$db->query($sql);
            return $list;
        }
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
    }

    function modifierproduit($idp,$nomprod,$description,$categorie,$prix,$quantite,$image)
    {
        $sql="update soujoud.produits set nomprod= '$nomprod', description='$description', categorie='$categorie',prix='$prix',quantite='$quantite ',image='$image' where idp='$idp'";
        $db = config11::getConnexion();
        try
        {
            $db->query($sql);
        }
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
    }

    function suppprod($idp)
    {
        $sql="DELETE FROM soujoud.produits WHERE idp LIKE '$idp' ESCAPE '#'";
        $db = config11::getConnexion();
        try
        {
            $db->query($sql);
        }
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
    }


function tri()
    {
        $sql="SElECT * From produits Order By prix Desc";;
        $db = config11::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

     function search($nomprod)
     {
         $sq1="select * from produits where nomprod='$nomprod'" ;
         $db = config11::getConnexion();
         try{
             $liste=$db->query($sq1);
             return $liste;
         }
         catch (Exception $e)
         {
             die('Erreur: '.$e->getMessage());
         }


     }

     function afficher($offset,$nb_page)
     {
         $sql="select * from soujoud.produits limit $offset  , $nb_page";
         $db = config11::getConnexion();
         try{
             $liste=$db->query($sql);
             return $liste ;
         }
         catch (Exception $e)
         {
             die('Erreur: '.$e->getMessage());
         }



     }
   }


?>
