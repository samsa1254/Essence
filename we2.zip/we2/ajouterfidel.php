<?php
include "entities/fidel.php";
include "core/fidelC.php";
session_start();
if(isset($_POST['idc']))
  {
      $cri=new fidel($_POST["FID"],$_POST["score"],$_POST["idc"],$_POST["promotion"]);
    $criC=new fidelC();
    $criC->ajouterfidel($cri);
    header("index2.php");

}


else
{
    echo " Déja non Utilisé";
}
?>
