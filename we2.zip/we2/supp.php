<?PHP
include "core/userC.php";
session_start();
$usuC=new utilisateurCore();
if (isset($_SESSION['l']))
{
	$usuC->supprimerClient($_SESSION['l']);
  header("location:index.php");
}

?>
