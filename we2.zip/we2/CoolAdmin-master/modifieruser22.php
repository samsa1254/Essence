<?php
include "core/userC.php";

$nom=$_POST["nom1"];
$prenom=$_POST["prenom1"];
$email=$_POST["mail1"];
$useC=new utilisateurCore();
if (isset($_SESSION['l']))
{
  $useC->modifierUser($nom,$prenom,$email,"","","","","");
  header("location:readuser.php");
}

?>
