<?php
include 'core/userC.php';
session_start();
$use = new utilisateurCore();
$listuser =$use->afficherUsers();
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!--Include the above in your HEAD tag ---------->

<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
<div class="container">
    <div class="row clearfix">
    	<div class="col-md-12 table-responsive">
			<table class="table table-bordered table-hover table-sortable" id="tab_logic">
    <tr>
        <td>nom</td>
        <td>prenom</td>
        <td>email</td>
        <td>adresse</td>
        <td>ville</td>
        <td>zip</td>
        <td>tel</td>
    </tr>
  </table>
  </div>
</div>
</div>
<?php

foreach ($listuser as $row)
{
    echo '

        <tr>
            <td>'.$row["nom"].'</td>
            <td>'.$row["prenom"].'</td>
            <td>'.$row["mail"].'</td>
            <td>'.$row["adresse"].'</td>
            <td>'.$row["ville"].'</td>
            <td>'.$row["zip"].'</td>
            <td>'.$row["tel"].'</td>

            <td>
                <form action="supp.php" method="get">
                    <input type="hidden" id="nom" name="nom" value="'.$row["nom"].'">
                    <input type="hidden" id="prenom" name="prenom" value="'.$row["prenom"].'">
                    <input type="hidden" id="mail" name="mail" value="'.$row["mail"].'">
                    <input type="hidden" id="adresse" name="adresse" value="'.$row["adresse"].'">
                    <input type="hidden" id="ville" name="ville" value="'.$row["ville"].'">
                    <input type="hidden" id="zip" name="zip" value="'.$row["zip"].'">
                    <input type="hidden" id="tel" name="tel" value="'.$row["tel"].'">

                </form>
            </td>
        </tr>


    ';
}
?>
</table>
<form class="" action="supp.php" method="post">
<h6>quel compte voulez vous supprimer? veuillez insrer l'adresse email du compte</h6>
  <input type="text" name="email22" value="" placeholder="email du compte">
  <input style="background: none; border: none; color: blue; text-decoration: underline;" type="submit" value="supprimer">

</form>
