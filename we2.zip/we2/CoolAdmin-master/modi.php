<?php

include "../core/ProduitsC.php";

$idp = $_GET["idp"];
$nomprod = $_GET["nomprod"];
$description = $_GET["description"];
$categorie = $_GET["categorie"];
$prix = $_GET["prix"];
$quantite = $_GET["quantite"];
$image = $_GET["image"];

$prodiC = new produitsC();
$prodiC->modifierproduit($idp, $nomprod, $description, $categorie, $prix,$quantite,$image);
//header("location:AfficherProduit%20(2).php");

?>
