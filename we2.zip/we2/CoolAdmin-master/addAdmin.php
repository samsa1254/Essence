<?php
include 'entities/user.php';
include 'core/userC.php';

if(isset($_POST['mail']) && isset($_POST['pseudo']) && isset($_POST['mdp']) && isset($_POST['prenom']))
{
  if(($_POST["role"])=="admin")
  {
    $c=new config();
    $conn=$c->getConnexion();
    $us=new utilisateur("",$_POST['prenom'],$_POST['pseudo'],$_POST['mail'],$_POST['mdp'],"","","","",$_POST["role"],$conn);
    $usC=new utilisateurCore();
    $d=$usC->inscritption($us);
    echo $d;
if($d!="23000")
  {
    echo $d;
    $u=$us->Logedin($conn,$_POST['mail'],$_POST['mdp']);
    if(!empty($_POST['mail']) && !empty($_POST['mdp']))
    {
      echo "connected";
     session_start();
     $_SESSION['l']=$_POST['mail'];
     $_SESSION['p']=$_POST['mdp'];
     header("location:verification.php");
    }

  }

}
}
else {
  echo 'taststs';
}
 ?>
