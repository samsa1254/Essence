<?php
include 'entities/user.php';
include'config.php';
$c=new config();
$conn=$c->getConnexion();
$user=new utilisateur("","","",$_POST['mailconnect'],"","","","","","",$conn);
$u=$user->Logedin1($conn,$_POST['mailconnect']);
$vide=false;

if(!empty($_POST['mailconnect']))
{
  foreach ($u as $t)
  {
    $vide=true;
    if($t['mail']==$_POST['mailconnect'])
    {
      session_start();
      $_SESSION['l']=$_POST['mailconnect'];
      header("location:index2.php");

       }
    // code...
  }
  if($vide==false)
  {
    echo "membre non reconnu";
  }
}
else {
  echo "non declaree";
}
?>
