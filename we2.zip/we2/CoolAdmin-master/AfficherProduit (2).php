<?PHP
include "../core/produitsC.php";
session_start();
if (isset($_SESSION['l']))
{

}
else {
  header("location:index.php");
}
$produit2C=new ProduitsC();
$listeProduits1=$produit2C->graphe();
$produitsC1=new produitsC();
$listeProduits=$produitsC1->afficherproduits();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="widtd=device-widtd, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au tdeme template">
    <meta name="autdor" content="Hau Nguyen">
    <meta name="keywords" content="au tdeme template">

    <!-- Title Page-->
    <title>Dashboard 3</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">



    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER DESKTOP-->
        <header class="header-desktop3 d-none d-lg-block">
            <div class="section__content section__content--p35">
                <div class="header3-wrap">
                    <div class="header__logo">
                            <img src="images/icon/logo-white.png" alt="CoolAdmin" />
                    </div>
                    <div class="header__navbar">
                        <ul class="list-unstyled">
                                    <li class="has-sub">
                                        <a class="js-arrow" href="#">
                                            <i class="fas fa-trophy"></i>Features
                                            <span class="arrow">
                                                <i class="fas fa-angle-down"></i>
                                            </span>
                                        </a>
                                        <ul class="list-unstyled navbar__sub-list js-sub-list">
                                            <li>
                                                <a href="table.html">
                                                    <i class="fas fa-table"></i>afficher reactions</a>
                                            </li>
                                            <li>
                                                <a href="readuser.php">
                                                    <i class="far fa-check-square"></i>verifier clients</a>
                                            </li>
                                        </ul>
                                    </li>

                            </li>
                        </ul>
                    </div>
                    <div class="header__tool">
                        <div class="header-button-item has-noti js-item-menu">
                            <i class="zmdi zmdi-notifications"></i>
                            <div class="notifi-dropdown notifi-dropdown--no-bor js-dropdown">
                                <div class="notifi__title">
                                    <p>You have 3 Notifications</p>
                                </div>
                                <div class="notifi__item">
                                    <div class="bg-c1 img-cir img-40">
                                        <i class="zmdi zmdi-email-open"></i>
                                    </div>
                                    <div class="content">
                                        <p>You got a email notification</p>
                                        <span class="date">April 12, 2018 06:50</span>
                                    </div>
                                </div>
                                <div class="notifi__item">
                                    <div class="bg-c2 img-cir img-40">
                                        <i class="zmdi zmdi-account-box"></i>
                                    </div>
                                    <div class="content">
                                        <p>Your account has been blocked</p>
                                        <span class="date">April 12, 2018 06:50</span>
                                    </div>
                                </div>
                                <div class="notifi__item">
                                    <div class="bg-c3 img-cir img-40">
                                        <i class="zmdi zmdi-file-text"></i>
                                    </div>
                                    <div class="content">
                                        <p>You got a new file</p>
                                        <span class="date">April 12, 2018 06:50</span>
                                    </div>
                                </div>
                                <div class="notifi__footer">
                                    <a href="#">All notifications</a>
                                </div>
                            </div>
                        </div>
                        <div class="header-button-item js-item-menu">
                            <i class="zmdi zmdi-settings"></i>
                            <div class="setting-dropdown js-dropdown">
                                <div class="account-dropdown__body">
                                    <div class="account-dropdown__item">
                                        <a href="#">
                                            <i class="zmdi zmdi-account"></i> gestion compte</a>
                                    </div>
                                </div>
                                <div class="account-dropdown__body">
                                    <div class="account-dropdown__item">
                                        <a href="#">
                                            <i class="zmdi zmdi-email"></i>Email</a>
                                    </div>
                                    <div class="account-dropdown__item">
                                        <a href="#">
                                            <i class="zmdi zmdi-notifications"></i>Notifications</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="account-wrap">
                            <div class="account-item account-item--style2 clearfix js-item-menu">
                                <div class="image">
                                    <img src="humen.jpg"/>
                                </div>
                                <div class="content">
                                    <a class="js-acc-btn">compte</a>
                                </div>
                                <div class="account-dropdown js-dropdown">
                                    <div class="info clearfix">
                                        <div class="content">
                                            <h5 class="name">
                                                <?php echo $_SESSION['pp']; ?>
                                            </h5>
                                            <span class="email"><?php echo $_SESSION['l']; ?></span>
                                        </div>
                                    </div>
                                    <div class="account-dropdown__body">
                                        <div class="account-dropdown__item">
                                            <a href="#">
                                                <i class="zmdi zmdi-settings"></i>modifier compte</a>
                                        </div>
                                    </div>
                                    <div class="account-dropdown__footer">
                                        <a href="dec.php">
                                            <i class="zmdi zmdi-power"></i>deconnexion</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER DESKTOP-->
        <!-- PAGE CONTENT-->
        <div class="page-content--bgf7">
            <!-- BREADCRUMB-->
            <section class="au-breadcrumb2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="au-breadcrumb-content">
                                <div class="au-breadcrumb-left">
                                    <span class="au-breadcrumb-span">Vous etes ici:</span>
                                    <ul class="list-unstyled list-inline au-breadcrumb__list">
                                        <li class="list-inline-item active">
                                            <a href="index2.php">acceuil</a>
                                        </li>
                                        <li class="list-inline-item seprate">
                                            <span>/</span>
                                        </li>
                                        <li class="list-inline-item">gestion produits</li>
                                    </ul>
                                </div>
                                <form class="au-form-icon--sm" action="" metdod="post">
                                    <input class="au-input--w300 au-input--style2" type="text" placeholder="Search for datas &amp; reports...">
                                    <button class="au-btn--submit2" type="submit">
                                        <i class="zmdi zmdi-search"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END BREADCRUMB-->

            <!-- WELCOME-->
            <section class="welcome p-t-10">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="title-4">Bienvenue
                                <span><?php echo $_SESSION['pp']; ?></span>
                            </h1>
                            <hr class="line-seprate">
                        </div>
                    </div>
                </div>
            </section>
            <!-- END WELCOME-->

            <!-- STATISTIC-->
            <form name="f" action="ajoutproduit.php" method="POST">
                <div class="row">
                    <div class="col-md-6 pr-md-1">
                        <div class="form-group">
                            <label>Id Produit</label>
                            <input type="text" class="form-control" placeholder="Id Produit" name="idp" id="IdProduit">
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-6 pr-md-1">
                        <div class="form-group">
                            <label>nom produit</label>
                            <input type="text" class="form-control" placeholder="nom de produit" name="nomprod" id="nom">

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Description</label>
                            <textarea rows="4" cols="80" class="form-control" name="description" placeholder="Description Produit"></textarea>

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 pr-md-1">
                        <div class="form-group">
                          <select class="" name="categorie">
                            <option value="femmes">femmes</option>
                            <option value="hommes">hommes</option>
                            <option value="enfants">enfants</option>
                          </select>
                        </div>
                    </div>

                </div>


                <div class="row">
                    <div class="col-md-6 pr-md-1">
                        <div class="form-group">
                            <label>Prix</label>
                            <input type="text" class="form-control" placeholder="Prix" name="prix" id="Prix">

                        </div>
                    </div>



                </div>





                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Quantite</label>
                            <input rows="4" cols="80" class="form-control" id="stock" name="quantite" placeholder="quantitet">

                        </div>
                    </div>
                </div>



                <div class="row">

                </div>
                <div class="row">



                </div>

                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Image</label>
                            <input rows="4" cols="80" class="form-control" name="image" placeholder="schema de l'image">

                        </div>
                    </div>
                </div>


                <div class="card-footer">
                    <input  type="submit" class="btn btn-fill btn-primary" >
            </form>
        </div>
            <!-- END STATISTIC-->

            <!-- STATISTIC CHART-->
        <link href="demo.css" rel="stylesheet" />
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">


            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);
            function drawChart()
            {
                var data = google.visualization.arrayToDataTable([
                    ['nom', 'prix'],
                    <?php
                    foreach ($listeProduits1 as $row)
                    {
                        echo "['".$row["nom"]."', ".$row["prix"]."],";

                    }
                    ?>

                ]);

                var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));


                var options = {"width":"700","height":"400","pieSliceText":"percentage","backgroundColor":"transparent"};
                chart.draw(data, options);


            }
        </script>
        <div id="barchart_values" style="width: 900px; height: 300px;"></div>

        <script src="chartjs.min.js"></script>

<br>
        <br>

            <!-- DATA TABLE-->
            <section class="p-t-20">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="title-5 m-b-35">data table</h3>
                            <div class="table-data__tool">
                                <div class="table-data__tool-left">
                                    <div class="rs-select2--light rs-select2--md">
                                        <select class="js-select2" name="property">
                                            <option selected="selected">All Properties</option>
                                            <option value="">Option 1</option>
                                            <option value="">Option 2</option>
                                        </select>
                                        <div class="dropDownSelect2"></div>
                                    </div>
                                    <div class="rs-select2--light rs-select2--sm">
                                        <select class="js-select2" name="time">
                                            <option selected="selected">Today</option>
                                            <option value="">3 Days</option>
                                            <option value="">1 Week</option>
                                        </select>
                                        <div class="dropDownSelect2"></div>
                                    </div>
                                    <button class="au-btn-filter">
                                        <i class="zmdi zmdi-filter-list"></i>filters</button>
                                </div>
                                <div class="table-data__tool-right">
                                    <a href="ajouterProduit.html" > <input class="au-btn au-btn-icon au-btn--green au-btn--small" value="ajouter produit" type="submit" ></a>

                                    <div class="rs-select2--dark rs-select2--sm rs-select2--dark2">
                                        <select class="js-select2" name="type">
                                            <option selected="selected">Export</option>
                                            <option value="">Option 1</option>
                                            <option value="">Option 2</option>
                                        </select>
                                        <div class="dropDownSelect2"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive table-responsive-data2">
                                <table class="table table-data2">


                                            <td>ID produit</td>
                                            <td>nom produit</td>
                                            <td>description</td>
                                            <td>categorie</td>
                                            <td>prix</td>
                                            <td>quantite</td>
                                            <td>image</td>
                                             <td>EDIT</td>
                                             <td>DELETE</td>
                                        </tr>


                                                  <?PHP
                                             foreach($listeProduits as $row)
                                             {
                                                       ?>
                                        <tr class="tr-shadow">
                                            <td>
                                                <label class="au-checkbox">
                                                    <input type="checkbox">
                                                    <span class="au-checkmark"></span>
                                                </label>
                                                            <tr>
                                             <td><?PHP echo $row['idp']; ?></td>
                                             <td><?PHP echo $row['nomprod']; ?></td>
                                           <td><?PHP echo $row['description']; ?></td>
                                              <td><?PHP echo $row['categorie']; ?></td>
                                             <td><?PHP echo $row['prix']; ?></td>
                                             <td><?PHP echo $row['quantite']; ?></td>
                                              <td><?PHP echo $row['image']; ?></td>
        <td>
            <form action="modif.php" method="GET">
                <input type="hidden" id="ref" name="idp" value="<?PHP echo $row['idp']; ?>">
                <input type="hidden" id="titre" name="nomprod" value="<?PHP echo $row['nomprod']; ?>">
                <input type="hidden" id="pre" name="description" value="<?PHP echo $row['description']; ?>">
                <input type="hidden" id="dat" name="categorie" value="<?PHP echo $row['categorie']; ?>">
                <input type="hidden" id="nbc" name="prix" value="<?PHP echo $row['prix']; ?>">
                <input type="hidden" id="nbc" name="quantite" value="<?PHP echo $row['quantite']; ?>">
                <input type="hidden" id="nbc" name="image" value="<?PHP echo $row['image']; ?>">


                <input class="item" data-toggle="tooltip" data-placement="top" title="Edit" type="submit" value="Edit" >
                <i class="zmdi zmdi-edit"></i>
            </form>
        </td>
        <td>
            <form action="supp22.php" method="post">
                <input type="hidden" id="ref" name="id" value="<?PHP echo $row['idp']; ?>">

                <input  class="item" data-toggle="tooltip" data-placement="top" title="Delete" type="submit" value="delete" >
                 <i class="zmdi zmdi-delete"></i>
            </form>
        </td>

    </tr>
    <?PHP
}
?>




                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END DATA TABLE-->

            <!-- COPYRIGHT-->
            <section class="p-t-60 p-b-20">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="copyright">
                                <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END COPYRIGHT-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
