<?php
include "../entities/produits.php";
include "../core/produitsC.php";
if(isset($_POST["idp"]) and isset($_POST["nomprod"]) and isset($_POST["description"]) and isset($_POST["categorie"]) and isset($_POST["prix"]) and isset($_POST["quantite"])and isset($_POST["image"]))
{
    $prod=new produits($_POST["idp"],$_POST["nomprod"],$_POST["description"],$_POST["categorie"],$_POST["prix"],$_POST["quantite"],$_POST["image"]);
    $prodC=new produitsC();
    $prodC->ajouterproduits($prod);
 header("location:AfficherProduit%20(2).php");
}

?>
