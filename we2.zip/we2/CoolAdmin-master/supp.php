<?PHP
include "core/userC.php";

if(isset($_POST['email22']))
{
$usuC=new utilisateurCore();
$email=$_POST['email22'];
	$usuC->supprimerClient($email);
	header('Location: index2.html'); //redirection
}

?>
