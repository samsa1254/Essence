<?php
include 'entities/user.php';
include'config.php';
$c=new config();
$conn=$c->getConnexion();
$user=new utilisateur("",$_POST['prenom'],$_POST['mailconnect'],$_POST['mdpconnect'],"","","","","","",$conn);
$u=$user->Logedin($conn,$_POST['mailconnect'],$_POST['mdpconnect']);
$vide=false;

if(!empty($_POST['mailconnect']) && !empty($_POST['mdpconnect']) && !empty($_POST['prenom']))
{
  foreach ($u as $t)
  {
    $vide=true;
    if($t['mail']==$_POST['mailconnect'] && $t['mdp']==$_POST['mdpconnect'] && $t['prenom']==$_POST['prenom'])
    {
      session_start();
      $_SESSION['l']=$_POST['mailconnect'];
      $_SESSION['p']=$_POST['mdpconnect'];
      $_SESSION['pp']=$_POST['prenom'];
      $_SESSION['r']=$_POST['role'];
      header("location:index2.php");

       }
    // code...
  }
  if($vide==false)
  {
    echo "membre non reconnu";
  }
}
else {
  echo "non declaree";
}
?>
