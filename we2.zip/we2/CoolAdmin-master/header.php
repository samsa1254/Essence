<div class="menu-sidebar2__content js-scrollbar1">
    <div class="account2">
        <div class="image img-cir img-120">
            <img src="images/icon/avatar-big-01.jpg" alt="John Doe" />
        </div>
        <h4 class="name">john doe</h4>
        <a href="#">Sign out</a>
    </div>
